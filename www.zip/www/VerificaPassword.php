
<?php 
    session_start();
    $SENHA;
    $SENHAB;
    $EMAIL;
 
 
      function PegaDados(){
    $SENHA = $_POST['psw'];
    $SENHAB = $_POST['psw-repeat'];
    $EMAIL = $_POST['email'];

    Compara($SENHA,$SENHAB);

     }

    function Compara($Senha1, $Senha2)
    {


     $SENHA = $_POST['psw'];
    $SENHAB = $_POST['psw-repeat'];
    $EMAIL = $_POST['email'];


        if($Senha1 == $Senha2){
        include 'abreConexao.php';

//VERIFICA SE JÁ NÃO SALVOU ESTE USUARIO
$sql = "SELECT * FROM `tb_administrador`";

$resultado =  $conexao->query($sql);
$verificador = 0;

while($row = $resultado->fetch_assoc()){
if($row['EMAIL'] == strtolower($EMAIL)){
    if($row['SENHA'] == $SENHA ){ // ENTRADA AUTORIZADA
        $verificador = 1;
        }
    }
}


if($verificador == 1){
    ?>
      <div class="alert alert-danger alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Atenção!</strong> Esse Usuario já foi Cadastrado !!
  </div>
  <?php
}else{ // SE NAO TIVER CADASTRA

    

    $sql = "INSERT INTO `tb_administrador` (`ID`, `EMAIL`, `SENHA`, `SENHA_ANTIGA`, `ERROS_LOGIN`) VALUES ('0', '$EMAIL', '$SENHA', '$SENHA', '0');";
    $sql = $conexao->query($sql);
   // header('location:index.php?info=error&msg=1');
    $_SESSION["ALERT"] = "Administrador cadastrado com sucesso!";
    header('location:index.php?');

}




include 'fechaConexao.php';
     




        }else{
            echo "SÃO DIFERENTES";


        }
    }

    PegaDados();

    ?>


  