
<?php 
	session_start();


$USUARIO = $_POST['uname'];
$SENHA= $_POST['psw'];

include 'abreConexao.php';


$sql = "SELECT * FROM `tb_administrador`";
$sqlLIDER = "SELECT * FROM `tb_lider_pesquisa`";



$resultado =  $conexao->query($sql);
$resultadoLider =  $conexao->query($sqlLIDER);

$verificador = 0;
$quantidadeDisponivel = 5;

//VERIFICA SE O USUARIO (ADMINISTRADOR) DIGITADO EXISTE E FAZ AS VERIFICAÇÕES
while($row = $resultado->fetch_assoc()){
if($row['EMAIL'] == strtolower($USUARIO)){
	if($row['ERROS_LOGIN'] < 5 ){
	if($row['SENHA'] == $SENHA ){ // ENTRADA AUTORIZADA
		$verificador = 1;
		$sql2 = "UPDATE tb_administrador SET ERROS_LOGIN = 0 WHERE EMAIL = '$USUARIO'";
		$sql2 = $conexao->query($sql2);
		
		//PASSA POR SESSION PARA OUTRA PAGINA
		$_SESSION["ID_USUARIO"] = $row['ID'];
		$_SESSION["TIPO_USUARIO"] = 1;
		$_SESSION["NOMEL"] = $row['EMAIL'];

	}else{ // ENTRADA NAO AUTORIZADA, DIMINUI 1 DA QUANTIDADE DE TENTATIVAS
		$sql2 = "UPDATE tb_administrador SET ERROS_LOGIN = ERROS_LOGIN+1 WHERE EMAIL = '$USUARIO'";
		$sql2 = $conexao->query($sql2);

		$quantidadeDisponivel = $row['ERROS_LOGIN'];

		if($row['ERROS_LOGIN'] > 3){
			$_SESSION["ALERT"] = "EXCEDEU O LIMITE DE TENTATIVAS TROQUE A SENHA";
			header("location:Login.php");
		}
	}

}else{ // SE CAIR AQUI, QUER DIZER QUE ERROU MAIS DE 5 VEZES A SENHA DESTE O USUARIO
$quantidadeDisponivel = 6;
}
	}else{
	if($verificador == 1){
		//faz nada
	}
}
	}

//VERIFICA SE O USUARIO (LIDER DE PESQUISA) DIGITADO EXISTE E FAZ AS VERIFICAÇÕES
while($row = $resultadoLider->fetch_assoc()){
if($row['PRONTUARIO'] == strtoupper($USUARIO)){
	if($row['ERROS_LOGIN'] < 5 ){
	if($row['SENHA'] == $SENHA ){ // ENTRADA AUTORIZADA
		$verificador = 1;
		$sql2 = "UPDATE tb_lider_pesquisa SET ERROS_LOGIN = 0 WHERE PRONTUARIO = '$USUARIO'";
		$sql2 = $conexao->query($sql2);
		
		//VERIFICAR O MOTIVO DE NAO ESTAR PASSANDO
		$_SESSION["ID_USUARIO"] = $row['ID'];
		$_SESSION["TIPO_USUARIO"] = 2;
		$_SESSION["NOMEL"] = $row['NOME'];

	}else{ // ENTRADA NAO AUTORIZADA, DIMINUI 1 DA QUANTIDADE DE TENTATIVAS
		$sql2 = "UPDATE tb_lider_pesquisa SET ERROS_LOGIN = ERROS_LOGIN+1 WHERE PRONTUARIO = '$USUARIO'";
		$sql2 = $conexao->query($sql2);

		$quantidadeDisponivel = $row['ERROS_LOGIN'];

		if($row['ERROS_LOGIN'] > 3){
			$_SESSION["ALERT"] = "EXCEDEU O LIMITE DE TENTATIVAS TROQUE A SENHA";
			header("location:Login.php");
		}
	}

}else{ // SE CAIR AQUI, QUER DIZER QUE ERROU MAIS DE 5 VEZES A SENHA DESTE O USUARIO
$quantidadeDisponivel = 6;
}
	}else{
	if($verificador == 1){
		//faz nada
	}
}
	}


// SE ACHOU ALGUM USUARIO ( ADMINISTRADOR OU LIDER AUTORIZADOS) CHAMA O INDEX.

$Aviso;

if($verificador == 1){
	header("location:index_logado.php");
}else{
		if($quantidadeDisponivel > 3){
			$Aviso .= "EXCEDEU O LIMITE DE TENTATIVAS TROQUE A SENHA   <br>   ";
			
		}

	$Aviso .= "Login Inválido!   <br>  ";
	

	if((4 -$quantidadeDisponivel) > 0){
		$Aviso .= "TENTATIVAS DISPONIVEIS: " . (4 -$quantidadeDisponivel) ;
	}



	$_SESSION["ALERT"] = $Aviso;
		header("location:Login.php");
}



include 'fechaConexao.php'
?>


