<?php 
	$conexao->close();
?>